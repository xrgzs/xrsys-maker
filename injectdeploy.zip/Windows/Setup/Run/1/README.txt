C:\Windows\Setup\Set\Run\1\api1.bat：进桌面OSC执行后OSCOnline执行前调用
C:\Windows\Setup\Set\Run\1\*.exe：进桌面OSC执行后OSCOnline执行前以 /S 参数执行 *.exe
C:\Windows\Setup\Set\Run\1\*.msi：进桌面OSC执行后OSCOnline执行前以 /passive /qb-! /norestart 参数执行 *.msi
C:\Windows\Setup\Set\Run\1\*.reg：进桌面OSC执行后OSCOnline执行前以 regedit /s 方式导入注册表
