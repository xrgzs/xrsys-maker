C:\Windows\Setup\Set\Run\2\api2.bat：进桌面OSC执行后OSCOnline执行后调用
C:\Windows\Setup\Set\Run\2\*.exe：进桌面OSC执行后OSCOnline执行后以 /S 参数执行 *.exe
C:\Windows\Setup\Set\Run\2\*.msi：进桌面OSC执行后OSCOnline执行后以 /passive /qb-! /norestart 参数执行 *.msi
C:\Windows\Setup\Set\Run\2\*.reg：进桌面OSC执行后OSCOnline执行后以 regedit /s 方式导入注册表