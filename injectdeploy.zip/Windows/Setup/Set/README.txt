脚本执行接口
仅供封装使用，其余用途不推荐此接口！！！
C:\Windows\Setup\Set\api1_bsq.bat：部署前最后调用
C:\Windows\Setup\Set\api2_bsz.bat：部署中最后调用
C:\Windows\Setup\Set\api3_bsh.bat：部署后最后调用
C:\Windows\Setup\Set\api4_dls.bat：登录时最后调用
C:\Windows\Setup\Set\api5_jzm.bat：进桌面OSC执行前调用
此接口使用 CALL 方式调用脚本，请勿添加 EXIT 命令，否则会导致部署失败

万能驱动执行接口
此接口可以去除万能驱动程序所附带的推广程序，仅供潇然系统内部使用
天空驱动请勿删除推广包，否则会导致无法部署
C:\Windows\Setup\Set\wandrv.iso：部署中自动挂载安装万能驱动ISO
C:\Windows\Setup\Set\wandrv2.iso：部署中自动挂载安装万能驱动ISO
C:\Windows\Setup\Set\CeoMSX.wim：部署中自动挂载安装 CeoMSX WIM（无清理）
C:\Windows\WinDrive\DcLoader.exe：部署中运行驱动总裁加载器（无清理）
......自动搜索常见封装系统总裁/天空驱动放置目录
C:\Windows\WinDrive（推荐，将驱动解压放置到此目录，潇然系统之前使用此接口）
C:\Sysprep\Drivers
C:\Sysprep
C:\wandrv\wandrv.exe

个性化接口
我们提供了接口供个性化界面元素、系统主题：

部署背景接口
C:\Windows\Setup\Set\BG.jpg：潇然系统部署背景插件 - 背景图片
C:\Windows\Version.txt：系统版本信息（潇然系统部署背景插件 - 副标题）
桌面壁纸接口
C:\Windows\Setup\Set\wallpaper.jpg：桌面壁纸
C:\Windows\Setup\xrsyswall.jpg：桌面壁纸
桌面背景将被复制到 C:\Windows\Version.jpg，所以无需担心删除