此目录为潇然系统优化组件 内部接口
此接口由 osc.exe 提供，仅提供桌面环境下的接口

在 C:\Windows\Setup\Set\osc\Office 目录下预留 Office ISO自动挂载安装接口
C:\Windows\Setup\Set\osc\Office\Office_年份版本号_大内部版本号_版本架构_版本类型.iso：进桌面OSC执行后OSCOnline执行前自动挂载安装Office ISO，详见其目录下 readme.md
在 C:\Windows\Setup\Set\osc 目录下预留 万能驱动 ISO自动挂载安装接口
C:\Windows\Setup\Set\osc\wandrv.iso：进桌面OSC执行后系统优化执行前自动挂载安装万能驱动 ISO（推荐驱动总裁）
C:\Windows\Setup\Set\osc\wandrv2.iso：进桌面OSC执行后系统优化执行前自动挂载安装万能驱动 ISO（推荐驱动总裁）
在 C:\Windows\Setup\Set\osc\runtime\Edge 目录下预留 Edge 自动安装接口
注意这里的安装包需要使用 EXE 格式的，获取地址：
https://chrome.noki.eu.org/edge
https://github.com/Bush2021/edge_installer
如果是MSI格式请用 C:\Windows\Setup\Set\Run\1\*.msi 这个 API
C:\Windows\Setup\Set\osc\runtime\Edge\*.exe：进桌面OSC执行后系统优化执行前安装 Edge 浏览器 + WebView2 运行库